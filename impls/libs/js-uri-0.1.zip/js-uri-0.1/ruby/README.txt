This directory contains an implementation of an URI parser and resolver written in Ruby.  It was written to aid the development of the JavaScript version, but may still be of interest.

@(#) $Id: README.txt 12 2007-04-26 19:48:08Z happygiraffe.net $
